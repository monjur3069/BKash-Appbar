package com.example.bkash_appbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
