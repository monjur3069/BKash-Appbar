import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomAppBar extends StatefulWidget {
  const CustomAppBar({Key? key}) : super(key: key);

  @override
  State<CustomAppBar> createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  bool _isBallanceShown = false;
  bool _isBallance = true;
  bool _isAnimation = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      width: MediaQuery.of(context).size.width,

      decoration: BoxDecoration(
          /*boxShadow: [
            BoxShadow(
                color: Colors.grey, blurRadius: 100.0.r, offset: Offset(0, -10))
          ],*/
          color: Colors.pink,
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            backgroundColor: Colors.green.shade50,
            radius: 20.r,
            child: Icon(
              Icons.person,
              color: Colors.pink,
              size: 28,
            ),
          ),
          SizedBox(
            width: 10.w,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Monjur Ahmed',
                style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              SizedBox(
                height: 5.h,
              ),
              InkWell(
                onTap: _showBalance,
                child: Container(
                  width: 160.w,
                  height: 28.h,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      AnimatedOpacity(
                        opacity: _isBallanceShown ? 1 : 0,
                        duration: Duration(milliseconds: 500),
                        child: Text(
                          '1020.00',
                          style: TextStyle(
                              color: Colors.pink,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      AnimatedOpacity(
                        opacity: _isBallance ? 1 : 0,
                        duration: const Duration(milliseconds: 500),
                        child: Text(
                          'Tap for Balance',
                          style: TextStyle(
                              color: Colors.pink,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      AnimatedPositioned(
                        //left: _isAnimation ? 135.sw : 5.sw,
                        left: _isAnimation ? 135.w : 5.w,
                        curve: Curves.fastOutSlowIn,
                        duration: const Duration(milliseconds: 1100),
                        child: Container(
                          height: 20.h,
                          width: 20.w,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              color: Colors.pink,
                              borderRadius: BorderRadius.circular(50.r)),
                          child: FittedBox(
                            child: Text(
                              '৳',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 17.sp,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            width: 10.w,
          ),
          SizedBox(
            width: 45.w,
            child: Image.asset('images/bkash.png'),
          ),

        ],
      ),
    );
  }

  void _showBalance() async {
    _isAnimation = true;
    _isBallance = false;
    setState(() {});

    await Future.delayed(Duration(milliseconds: 800),
        () => setState(() => _isBallanceShown = true));
    await Future.delayed(Duration(milliseconds: 1500),
        () => setState(() => _isBallanceShown = false));
    await Future.delayed(Duration(milliseconds: 200),
        () => setState(() => _isAnimation = false));
    await Future.delayed(
        Duration(milliseconds: 800), () => setState(() => _isBallance = true));
  }
}
