
import 'package:bkash_appbar/pages/custom_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HomePage extends StatefulWidget {
  static const String routeName = '/home';
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(80),
          child: CustomAppBar(),
        ),
        body: ListView(
          children: [
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(10))
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Send_Money.PNG'),
                              ),
                              Text('Send Money',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Mobile_Recharge.PNG'),
                              ),
                              Text('Mobile Reacharge',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/CashOut.png'),
                              ),
                              Text('Cash Out',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/MakePayment.png'),
                              ),
                              Text('Make Payment',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 15.h,),
                      Row(
                        children: [
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/AddMoney.png'),
                              ),
                              Text('Add Money',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Pay_Bill.PNG'),
                              ),
                              Text('Pay Bill',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Savings.PNG'),
                              ),
                              Text('Savings',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Loan.PNG'),
                              ),
                              Text('Loan',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 15.h,),
                      Row(
                        children: [
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/AddMoney.png'),
                              ),
                              Text('Add Money',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Pay_Bill.PNG'),
                              ),
                              Text('Pay Bill',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Savings.PNG'),
                              ),
                              Text('Savings',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                          Expanded(child: SizedBox()),
                          Column(
                            children: [
                              Tab(
                                icon: new Image.asset('images/Loan.PNG'),
                              ),
                              Text('Loan',style: TextStyle(color: Colors.grey.shade600,fontSize: 14.sp),)
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
        ),
    );
  }
}
